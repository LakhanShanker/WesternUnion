package com.bank.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Assignment {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	long tokenNumber;
	@Column
	long id;
	@Column
	String accountNumber;
	public long getTokenNumber() {
		return tokenNumber;
	}
	public void setTokenNumber(long tokenNumber) {
		this.tokenNumber = tokenNumber;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Assignment( long id, String accountNumber) {
		super();
	//	this.tokenNumber = tokenNumber;
		this.id = id;
		this.accountNumber = accountNumber;
	}
	public Assignment() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
