package com.bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WuBankApplication {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Welcome to Banking");
		SpringApplication.run(WuBankApplication.class, args);
		
	}

}
