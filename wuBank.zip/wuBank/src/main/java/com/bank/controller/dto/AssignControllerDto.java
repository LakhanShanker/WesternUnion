package com.bank.controller.dto;

public class AssignControllerDto {

	String name;
	String accountNumber;
	String withdrawlAmount;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getWithdrawlAmount() {
		return withdrawlAmount;
	}
	public void setWithdrawlAmount(String withdrawlAmount) {
		this.withdrawlAmount = withdrawlAmount;
	}
	public AssignControllerDto(String name, String accountNumber, String withdrawlAmount) {
		super();
		this.name = name;
		this.accountNumber = accountNumber;
		this.withdrawlAmount = withdrawlAmount;
	}
	public AssignControllerDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
