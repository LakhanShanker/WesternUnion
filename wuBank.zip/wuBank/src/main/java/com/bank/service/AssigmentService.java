package com.bank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bank.controller.dto.AssignControllerDto;
import com.bank.entity.Assignment;
import com.bank.entity.Customer;
import com.bank.repo.Assign;
import com.bank.repo.CustomerRepo;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
@Transactional
public class AssigmentService {

	@Autowired
	Assign assignRepo;
	@Autowired
	CustomerRepo customerRepo;
	
	public String assignAgent(AssignControllerDto dto) {
		Customer cust = new ObjectMapper().convertValue(dto,Customer.class);
		
		long custId = customerRepo.save(cust).getId();
		String accNum = customerRepo.save(cust).getAccountNumber();
		
		System.out.println("Customer added successfully");
		
		Assignment assign = new Assignment(custId,accNum);
		
		long assignNum = assignRepo.save(assign).getTokenNumber();
		
		return "Your Token id is : "+assignNum; 
		
		
	}
}
