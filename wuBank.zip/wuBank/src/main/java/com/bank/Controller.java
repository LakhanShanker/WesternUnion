package com.bank;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.controller.dto.AssignControllerDto;
import com.bank.service.AssigmentService;

@RestController
@RequestMapping("api")
public class Controller {

	@Autowired
	AssigmentService assignment;
	
	@PostMapping("/assign")
	public String AssignAgent(@RequestBody AssignControllerDto dto) {
		return assignment.assignAgent(dto);
	}
	
	@PostConstruct
	public void destroy() {
		System.out.println("Thank you for banking with us.");
	}
	
	
}
