package com.employee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/employee")
@RestController
public class EmpController {

	EmpService emprepo;
	@Autowired
	EmpController(EmpService emprepo){
		this.emprepo=emprepo;
	}
	@GetMapping("/")
	public ResponseEntity<List<Employee>> getAll(){
		return ResponseEntity.ok(emprepo.findAll());	
	}
	@GetMapping("/{id}")
	public ResponseEntity<Employee> get(@PathVariable long id){
		return ResponseEntity.ok(emprepo.findById(id).orElse(null));	
	}
	
	@PostMapping("/")
	public ResponseEntity<Employee> add(@RequestBody Employee e){
		return ResponseEntity.ok(emprepo.save(e));
	}
	
}
