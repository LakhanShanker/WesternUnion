package springweb.demo;

import java.util.*;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("student")
public class StudentController {
	@Autowired
	private StudentRepo studentRepo;
	
	@GetMapping("/")
	public ModelAndView getstudent() {
		List<Student> l = studentRepo.findAll();
		HashMap<String, List<Student>> m = new HashMap<>();
		m.put("mystudents", l);
		return new ModelAndView("student",m);
	}
	@GetMapping("/helloadmin")
	public String getlogin() {
		return "login";
	}

	@RequestMapping(value = "/form", method = RequestMethod.GET)
	public ModelAndView getform() {
		return new ModelAndView("form");
	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit() {
		return new ModelAndView("edit");
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String updatestudent(HttpServletRequest req) {
		long id = Long.parseLong(req.getParameter("id"));
		String name = req.getParameter("name");
		System.out.println(name);
		String phone = req.getParameter("phone");
		String college = req.getParameter("college");
		Optional<Student> s = studentRepo.findById(id);
		Student stu = s.get();
		stu.setName(name);
		stu.setPhone(phone);
		stu.setCollege(college);
		studentRepo.save(stu);
		
		return "redirect:/student/";
	}
	@RequestMapping(value = "/form",  method = RequestMethod.POST)
	public String addstudent(HttpServletRequest req) {
		String name = req.getParameter("name");
		String phone = req.getParameter("phone");
		String college = req.getParameter("college");
		Student s = new Student(name,phone,college);
		studentRepo.save(s);
		
		return "redirect:/student/";
	}
	
	@RequestMapping(value = "/delete/{id}" , method = RequestMethod.GET)
	public String delstudent(@PathVariable("id") long id) {
		
		studentRepo.deleteById(id);
		return "redirect:/student/";
	}
	@RestController
	public class ResourceController {

	@RequestMapping({"/hellouser"})
	public String helloUser(){
	return "<!DOCTYPE html>\r\n"
	+ "<html>\r\n"
	+ "<head>\r\n"
	+ "<meta charset=\"ISO-8859-1\">\r\n"
	+ "<meta http-equiv=\"refresh\" content=\"1; url = http://localhost:8080/student/\" />\r\n"
	+ "<title>Success</title>\r\n"
	+ "</head>\r\n"
	+ "<body>\r\n"
	+ "<h1> Welcome User. </h1>\r\n"
	+ "</body>\r\n"
	+ "</html>";
	}

	@RequestMapping({"/helloadmin"})
	public String helloAdmin(){
	return "<!DOCTYPE html>\r\n"
	+ "<html>\r\n"
	+ "<head>\r\n"
	+ "<meta charset=\"ISO-8859-1\">\r\n"
	+ "<meta http-equiv=\"refresh\" content=\"1; url = http://localhost:8080/student/\" />\r\n"
	+ "<title>Success</title>\r\n"
	+ "</head>\r\n"
	+ "<body>\r\n"
	+ "<h1> Welcome Admin. </h1>\r\n"
	+ "</body>\r\n"
	+ "</html>";
	}



	}
	
}
