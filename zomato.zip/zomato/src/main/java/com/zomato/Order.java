package com.zomato;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class Order {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration con = new Configuration().configure().addAnnotatedClass(Food.class);
		SessionFactory sf = con.buildSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		
		Query query = session.createQuery("from Food");
		java.util.List stu = query.list();
		for(Object ee : stu) {
			
			System.out.println(ee.toString());
			System.out.println();
		}
		session.getTransaction().commit();
		sf.close();
	}

}
