package com.zomato;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class UpdateCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration con = new Configuration().configure().addAnnotatedClass(Customer.class);
		SessionFactory sf = con.buildSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter id to update");
		int id = sc.nextInt();
		Customer  ee = (Customer)session.get(Customer.class, id);
		System.out.println(ee.toString());
		System.out.println("1. Name");
		System.out.println("2. Phone");
		System.out.println("3. Address");
		System.out.println("Enter to update");
		int choose = sc.nextInt();
		sc.nextLine();
		boolean cho = true;
		if(choose == 1) {
			System.out.println("Enter new Name to update");
			String name = sc.nextLine();
			ee.setName(name);
		}
		else if(choose == 2){
			System.out.println("Enter new Phone to update");
			String phone = sc.nextLine();
			ee.setPhone(phone);
		}
		else if (choose == 3) {
			System.out.println("Enter new Address to update");
			String address = sc.nextLine();
			ee.setAddress(address);
		}
		else {
			System.out.println("Invalid Choice");
			cho = false;
		}
		
		if(cho)
		session.update(ee);
		
		System.out.println("Details Updated successfully");
		session.getTransaction().commit();
		sf.close();
	}

}
