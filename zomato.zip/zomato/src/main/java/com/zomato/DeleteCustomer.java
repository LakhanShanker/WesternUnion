package com.zomato;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class DeleteCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration con = new Configuration().configure().addAnnotatedClass(Customer.class);
		SessionFactory sf = con.buildSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter id to be deleted");
		int id = sc.nextInt();
		Customer  ee = (Customer)session.load(Customer.class, id);
		System.out.println(ee.toString());
		boolean wants = false;
		System.out.println("Want to delete (Y/N)");
		String ans = sc.next();
		if(ans.equalsIgnoreCase("y")) {
		session.delete(ee);
		System.out.println("Deleted successfully");
		}
		else {
			System.out.println("Deleted operation aborted");
		}
		session.getTransaction().commit();
		sf.close();

	}

}
