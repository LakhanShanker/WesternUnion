package com.zomato;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class CreateAccount{
	public static void main(String[] args) throws Exception {
		Customer c = new Customer();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter customer id");
		int id = sc.nextInt();
		c.setId(id);
		sc.nextLine();
		System.out.println("Enter name");
		String name = sc.nextLine();
		c.setName(name);
		
		System.out.println("Enter phone");
		String phone = sc.nextLine();
		c.setPhone(phone);
		System.out.println("Enter Address");
		String address = sc.nextLine();
		c.setAddress(address);
		
		Configuration con = new Configuration().configure().addAnnotatedClass(Customer.class);
		SessionFactory sf = con.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tcn = session.beginTransaction();
		session.save(c);
		tcn.commit();
		System.out.println("Customer added Successfully..");

	}


}
