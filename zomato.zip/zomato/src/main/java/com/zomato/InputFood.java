package com.zomato;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class InputFood {
	public static void main(String[] args) {
		Food emp = new Food();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter id");
		int id = sc.nextInt();
			
		
		
		Configuration con = new Configuration().configure().addAnnotatedClass(Food.class);
		SessionFactory sf = con.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tcn = session.beginTransaction();
		session.save(emp);
		tcn.commit();
		System.out.println("Added Successfully..");
		
	}
}
