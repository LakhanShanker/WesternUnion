package com.zomato;

import javax.persistence.*;

@Entity
public class Food{
	@Id
	int f_id;
	@Column
	String f_name;
	@Column
	int f_price;
	
	
	@Override
	public String toString() {
		return "Food [f_id=" + f_id + ", f_name=" + f_name + ", f_price=" + f_price + "]";
	}
	public int getF_id() {
		return f_id;
	}
	public void setF_id(int f_id) {
		this.f_id = f_id;
	}
	public String getF_name() {
		return f_name;
	}
	public void setF_name(String f_name) {
		this.f_name = f_name;
	}
	public int getF_price() {
		return f_price;
	}
	public void setF_price(int f_price) {
		this.f_price = f_price;
	}
	public Food() {
		super();
		// TODO Auto-genepriced constructor stub
	}
	public Food(int f_id, String f_name, int f_price) {
		super();
		this.f_id = f_id;
		this.f_name = f_name;
		this.f_price = f_price;
	}
	
	
}
