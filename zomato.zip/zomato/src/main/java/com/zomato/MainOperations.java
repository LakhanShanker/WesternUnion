package com.zomato;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;


public class MainOperations {

	public static void main(String[] args) throws Exception {
		
		Scanner sc = new Scanner(System.in);
		int n=0;
		int bal = 0;
		String op="";
		do {
			System.out.println("Choose operation to perform");
			System.out.println("1. Add new Customer");
			System.out.println("2. Show all data of Customer");
			System.out.println("3. Update Data");
			System.out.println("4. Delete Data");
			System.out.println("5. Exit");
			System.out.println("6. Order Food");
			n = sc.nextInt();
			sc.nextLine();
			if(n==1) {
				new CreateAccount().main(args);
			}
			else if(n==2) {
				new ReadCustomer().main(args);
			}
			else if(n==3) {
				new UpdateCustomer().main(args);
			}
			else if(n==4) {
				new DeleteCustomer().main(args);
			}
			else if(n==5) {
				System.out.println("Thank You");
				return;
			}
			else if(n==6) {
				Order o = new Order();
				Food f1 = new Food();
				String food_name = "";
				o.main(args);
				System.out.println("Choose food");
				int f = sc.nextInt();
				if(f==1) {
					bal = 90; 
				}
				else if(f==2) {
					bal = 50; 
				}
				else if(f==3) {
					bal = 120; 
				}
				else if(f==4) {
					bal = 20; 
				}
				else if(f==5) {
					bal = 50; 
				}
				else if(f==6) {
					bal = 30; 
				}				
			}
			else {
				System.out.println("Invalid Operation");
			}
			System.out.println("Want to continue (Y/N)");
			op=sc.next();
			if(op.equalsIgnoreCase("n")) {
				System.out.println("Thank You");
				return;
			}
		}while(n!=5);		
		
	}

}
