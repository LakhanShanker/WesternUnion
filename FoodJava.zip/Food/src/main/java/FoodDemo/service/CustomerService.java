package FoodDemo.service;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import FoodDemo.food.Customer;

@Service
public interface CustomerService extends JpaRepository<Customer,Long> {

}
