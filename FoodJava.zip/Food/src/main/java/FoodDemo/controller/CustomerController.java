package FoodDemo.controller;

import java.util.List;
import java.util.Optional;

import javax.management.AttributeNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import FoodDemo.food.Customer;
import FoodDemo.service.CustomerService;

@RequestMapping("/customer/api")
@RestController
public class CustomerController {
CustomerService f;
	
	@Autowired
	public void setCustomerService(CustomerService f) {
		this.f = f;
	}
	@GetMapping("/")
	public ResponseEntity<List<Customer>> getAll() {
		return ResponseEntity.ok(f.findAll());
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Customer> findById(@PathVariable Long id) {
		return ResponseEntity.ok(f.findById(id).orElse(null));
	}
	
	@PostMapping("/")
	public ResponseEntity<Customer> add(@RequestBody Customer fo) {
		return ResponseEntity.ok(f.save(fo));
	}
	
	@PutMapping("/{id}")
    public ResponseEntity<Object> updateStudent(@RequestBody Customer employee, @PathVariable long id) {        
		Optional<Customer> cust = null;
        try {
        	cust = f.findById(id);
        } catch (Exception e) {
            e.printStackTrace();
        }         if (!cust.isPresent())
            return ResponseEntity.notFound().build();         
        employee.setId(id);

        f.save(employee);         
        return ResponseEntity.noContent().build();
    }

	
//	@PutMapping("/")
//	public ResponseEntity<Customer> update(@RequestBody Customer fo) {
//		return ResponseEntity.ok(f.save(fo));
//	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Customer> delete(@PathVariable Long id) {
		f.findById(id).ifPresent(f::delete);
		return ResponseEntity.ok().build();
	}
	
	
}
